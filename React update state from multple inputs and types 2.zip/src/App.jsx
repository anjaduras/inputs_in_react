// https://www.pluralsight.com/guides/handling-multiple-inputs-with-single-onchange-handler-react
// https://dev.to/deboragaleano/how-to-handle-multiple-inputs-in-react-55el
// https://dmitripavlutin.com/controlled-inputs-using-react-hooks/

import "./App.css";
import Diagramm from "./controlled-4.svg";
import { useState, useRef } from "react";

function App() {
  // ##################EXAMPLE 1
  function handleChange_ex1(evt) {
    console.log("new value example 1", evt.target.value);
  }
  // ##################EXAMPLE 1b - useRef instead of useState
  const secondname = useRef(null);

  function handleSubmit1b (evt) {
    evt.preventDefault();
    console.log({secondname: secondname.current.value})
  }

  // ##################EXAMPLE 2
  const [state, setState] = useState({
    firstName: "",
  });
  function handleChange_ex2(evt) {
    console.log("new value example 2", evt.target.value);
    setState({ firstName: evt.target.value });
  }
  // ##################EXAMPLE 3
  const [state3, setState3] = useState({
    firstName: "",
    lastName: "",
  });
  function handleChange_ex3(evt) {
    const value = evt.target.value;
    setState3({ ...state3, [evt.target.name]: value });
    console.log("new value example 3", state3);
  }
  // ##################EXAMPLE 4
  const [state4, setState4] = useState({
    bio: "",
  });
  function handleChange_ex4(evt) {
    console.log("new value example 4", evt.target.value);
    setState4({ bio: evt.target.value });
    console.log("new value example 4", state4);
  }
  // ##################EXAMPLE 5
  const [state5, setState5] = useState({ version: "16.8" });

  function handleChange_ex5(evt) {
    console.log("new value example 5", evt.target.value);
    setState5({ version: evt.target.value });
    console.log("new value example 5", state5);
  }
  // ##################EXAMPLE 6
  const [state6, setState6] = useState({ level: "master" });

  function handleChange_ex6(evt) {
    console.log("new value example 6", evt.target.value);
    setState6({ level: evt.target.value });
  }
  // ##################EXAMPLE 7
  const [state7, setState7] = useState({ hook1: true, hook2: true });

  function handleChange_ex7(evt) {
    console.log("new value example 7 of ", evt.target.name, evt.target.checked);
    const value =
      evt.target.type === "checkbox" ? evt.target.checked : evt.target.value;

    setState7({ ...state7, [evt.target.name]: value });
    console.log(state7);
  }
  // renderung examples from here

  return (
    <div className="App">
      <p>EXAMPLE 1 - A Single Input</p>
      <label>
        First name
        <input type="text" onChange={handleChange_ex1} />
      </label>

      <p>EXAMPLE 1b - A Single Input (useRef)</p>

      <form onSubmit={handleSubmit1b}>
        <label>
          Second name
          <input type="text" name="secondname" ref={secondname} />
        </label>
        <button type="submit">Send</button>
      </form>

      <hr />

      <p>EXAMPLE 2 - A Controlled Component</p>
      <label>
        First name
        <input type="text" onChange={handleChange_ex2} />
      </label>
      <img src={Diagramm} alt="Diagramm controlled component" width="300" />
      <hr />

      <p>EXAMPLE 3 - Multiple Inputs</p>

      <label>
        First name
        <input
          type="text"
          name="firstName"
          value={state3.firstName}
          onChange={handleChange_ex3}
        />
      </label>
      <br />
      <label>
        Last name
        <input
          type="text"
          name="lastName"
          value={state3.lastName}
          onChange={handleChange_ex3}
        />
      </label>

      <hr />

      <p>EXAMPLE 4 - TextArea Inputs</p>
      <label>
        Bio
        <textarea name="bio" value={state4.bio} onChange={handleChange_ex4} />
      </label>

      <hr />
      <p>EXAMPLE 5 - Select Inputs</p>
      <label>
        Favorite version
        <select
          name="version"
          onChange={handleChange_ex5}
          value={state5.version}
        >
          <option value="16.8">v16.8.0</option>
          <option value="16.7">v16.7.0</option>
          <option value="16.6">v16.6.0</option>
          <option value="16.5">v16.5.0</option>
        </select>
      </label>
      <hr />

      <p>EXAMPLE 6 - Radio Inputs</p>
      <form>
        <div>
          Level
          <label>
            Acolyte
            <input
              type="radio"
              name="level"
              value="acolyte"
              checked={state6.level === "acolyte"}
              onChange={handleChange_ex6}
            />
          </label>
          <label>
            Master
            <input
              type="radio"
              name="level"
              value="master"
              checked={state6.level === "master"}
              onChange={handleChange_ex6}
            />
          </label>
        </div>
      </form>

      <hr />

      <p>EXAMPLE 7 - Checkbox Inputs</p>

      <label>
        With hook 1
        <input
          type="checkbox"
          name="hook1"
          checked={state7.hook1}
          onChange={handleChange_ex7}
        />
      </label>
      <label>
        With hook 2
        <input
          type="checkbox"
          name="hook2"
          checked={state7.hook2}
          onChange={handleChange_ex7}
        />
      </label>
    </div>
  );
}

export default App;
